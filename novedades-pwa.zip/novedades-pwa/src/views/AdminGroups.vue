<template>
  <div class="min-h-screen bg-slate-50">
    <header class="sticky top-0 z-10 backdrop-blur bg-white/70 border-b border-slate-200">
      <div class="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <h1 class="text-slate-900 font-semibold">Grupos</h1>
        <nav class="flex items-center gap-3">
          <router-link to="/admin" class="btn-ghost">Dashboard</router-link>
          <router-link to="/admin/users" class="btn-ghost">Usuarios</router-link>
          <button @click="logout" class="btn-ghost">Cerrar sesión</button>
        </nav>
      </div>
    </header>

    <main class="max-w-6xl mx-auto px-4 py-6 space-y-6">
      <div class="card">
        <div class="card-body flex flex-col md:flex-row gap-3">
          <input v-model="newCode" placeholder="Código (ej. GRUPO F)" class="input md:w-60">
          <button @click="createGroup" class="btn-primary md:w-auto w-full">Crear</button>
          <span class="text-sm" :class="msgClass" v-if="msg">{{ msg }}</span>
        </div>
      </div>

      <div class="card">
        <div class="card-body">
          <table class="table">
            <thead>
              <tr><th>ID</th><th>Código</th><th>Usuarios</th><th>Acciones</th></tr>
            </thead>
            <tbody>
              <tr v-for="g in groups" :key="g.id">
                <td>{{ g.id }}</td>
                <td>
                  <input v-model="g.code" class="input w-48">
                </td>
                <td>{{ g.usersCount }}</td>
                <td class="flex gap-2">
                  <button class="btn-primary" @click="updateGroup(g)">Guardar</button>
                  <button class="btn-ghost" @click="removeGroup(g)">Eliminar</button>
                </td>
              </tr>
              <tr v-if="groups.length === 0"><td colspan="4" class="text-center text-slate-500">Sin grupos</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import axios from 'axios'

const groups = ref([])
const newCode = ref('')
const msg = ref('')
const msgClass = computed(()=> msg.value.includes('✅') ? 'text-green-600' : 'text-red-600')

async function load(){ 
  const { data } = await axios.get('/adminapi/groups', { headers: { Authorization: 'Bearer ' + localStorage.getItem('token') }})
  groups.value = data
}
async function createGroup(){
  msg.value = ''
  try {
    await axios.post('/adminapi/groups', { code: newCode.value }, { headers: { Authorization: 'Bearer ' + localStorage.getItem('token') }})
    newCode.value = ''
    msg.value = 'Creado ✅'
    await load()
  } catch(e){ msg.value = e.response?.data?.detail || e.response?.data?.error || 'Error' }
}
async function updateGroup(g){
  msg.value = ''
  try {
    await axios.patch(`/adminapi/groups/${g.id}`, { code: g.code }, { headers: { Authorization: 'Bearer ' + localStorage.getItem('token') }})
    msg.value = 'Guardado ✅'
    await load()
  } catch(e){ msg.value = e.response?.data?.detail || e.response?.data?.error || 'Error' }
}
async function removeGroup(g){
  msg.value = ''
  try {
    await axios.delete(`/adminapi/groups/${g.id}`, { headers: { Authorization: 'Bearer ' + localStorage.getItem('token') }})
    msg.value = 'Eliminado ✅'
    await load()
  } catch(e){ msg.value = e.response?.data?.detail || e.response?.data?.error || 'Error' }
}
function logout(){ localStorage.removeItem('token'); window.location.href = '/login' }
onMounted(load)
</script>
