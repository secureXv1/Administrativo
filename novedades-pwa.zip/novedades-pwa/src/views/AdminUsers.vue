<template>
  <div class="min-h-screen bg-slate-50">
    <header class="sticky top-0 z-10 backdrop-blur bg-white/70 border-b border-slate-200">
      <div class="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <h1 class="text-slate-900 font-semibold">Usuarios</h1>
        <nav class="flex items-center gap-3">
          <router-link to="/admin" class="btn-ghost">Dashboard</router-link>
          <router-link to="/admin/groups" class="btn-ghost">Grupos</router-link>
          <button @click="logout" class="btn-ghost">Cerrar sesión</button>
        </nav>
      </div>
    </header>

    <main class="max-w-6xl mx-auto px-4 py-6 space-y-6">
      <div class="card">
        <div class="card-body grid grid-cols-1 md:grid-cols-5 gap-3">
          <input v-model="newUser.email" placeholder="email" class="input">
          <select v-model="newUser.role" class="input">
            <option value="leader">leader</option>
            <option value="admin">admin</option>
          </select>
          <select v-model="newUser.groupId" class="input" :disabled="newUser.role==='admin'">
            <option :value="null">— grupo —</option>
            <option v-for="g in groups" :key="g.id" :value="g.id">{{ g.code }}</option>
          </select>
          <input v-model="newUser.password" placeholder="password inicial" class="input" type="password">
          <button @click="createUser" class="btn-primary">Crear</button>
        </div>
        <div class="px-4 pb-3">
          <span class="text-sm" :class="msgClass" v-if="msg">{{ msg }}</span>
        </div>
      </div>

      <div class="card">
        <div class="card-body">
          <table class="table">
            <thead>
              <tr><th>ID</th><th>Email</th><th>Rol</th><th>Grupo</th><th>Reset pass</th><th>Acciones</th></tr>
            </thead>
            <tbody>
              <tr v-for="u in users" :key="u.id">
                <td>{{ u.id }}</td>
                <td>{{ u.email }}</td>
                <td>
                  <select v-model="u.role" class="input w-28">
                    <option value="leader">leader</option>
                    <option value="admin">admin</option>
                  </select>
                </td>
                <td>
                  <select v-model="u.groupId" class="input w-40" :disabled="u.role==='admin'">
                    <option :value="null">— grupo —</option>
                    <option v-for="g in groups" :key="g.id" :value="g.id">{{ g.code }}</option>
                  </select>
                </td>
                <td>
                  <input v-model="u._newPass" class="input w-40" type="password" placeholder="nuevo password (opcional)">
                </td>
                <td class="flex gap-2">
                  <button class="btn-primary" @click="updateUser(u)">Guardar</button>
                  <button class="btn-ghost" @click="removeUser(u)">Eliminar</button>
                </td>
              </tr>
              <tr v-if="users.length===0"><td colspan="6" class="text-center text-slate-500">Sin usuarios</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import axios from 'axios'

const users = ref([])
const groups = ref([])
const newUser = ref({ email:'', role:'leader', groupId:null, password:'' })
const msg = ref('')
const msgClass = computed(()=> msg.value.includes('✅') ? 'text-green-600' : 'text-red-600')

async function load(){
  const [gu, us] = await Promise.all([
    axios.get('/adminapi/groups', { headers: { Authorization: 'Bearer ' + localStorage.getItem('token') } }),
    axios.get('/adminapi/users',  { headers: { Authorization: 'Bearer ' + localStorage.getItem('token') } })
  ])
  groups.value = gu.data
  users.value = us.data.map(x => ({ ...x, _newPass:'' }))
}

async function createUser(){
  msg.value = ''
  try {
    await axios.post('/adminapi/users', newUser.value, { headers: { Authorization: 'Bearer ' + localStorage.getItem('token') } })
    msg.value = 'Creado ✅'
    newUser.value = { email:'', role:'leader', groupId:null, password:'' }
    await load()
  } catch(e){ msg.value = e.response?.data?.detail || e.response?.data?.error || 'Error' }
}

async function updateUser(u){
  msg.value = ''
  try {
    await axios.patch(`/adminapi/users/${u.id}`, {
      role: u.role,
      groupId: u.role === 'leader' ? u.groupId : null,
      password: u._newPass || undefined
    }, { headers: { Authorization: 'Bearer ' + localStorage.getItem('token') } })
    msg.value = 'Guardado ✅'
    await load()
  } catch(e){ msg.value = e.response?.data?.detail || e.response?.data?.error || 'Error' }
}

async function removeUser(u){
  msg.value = ''
  try {
    await axios.delete(`/adminapi/users/${u.id}`, { headers: { Authorization: 'Bearer ' + localStorage.getItem('token') } })
    msg.value = 'Eliminado ✅'
    await load()
  } catch(e){ msg.value = e.response?.data?.detail || e.response?.data?.error || 'Error' }
}

function logout(){ localStorage.removeItem('token'); window.location.href = '/login' }

onMounted(load)
</script>
