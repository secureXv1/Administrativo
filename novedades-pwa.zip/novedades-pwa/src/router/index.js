import { createRouter, createWebHistory } from 'vue-router'
import ReportView from '../views/ReportView.vue'
import LoginView from '../views/LoginView.vue'
import AdminDashboard from '../views/AdminDashboard.vue'
import axios from 'axios'
import AdminGroups from '../views/AdminGroups.vue'
import AdminUsers from '../views/AdminUsers.vue'

const routes = [
  { path: '/', redirect: '/login' },
  { path: '/login', component: LoginView },
  { path: '/report', component: ReportView },
  { path: '/admin', component: AdminDashboard },
  { path: '/admin/groups', component: AdminGroups }, // 👈
  { path: '/admin/users', component: AdminUsers }    // 👈
]

const router = createRouter({ history: createWebHistory(), routes })

async function getMe(token) {
  try {
    const { data } = await axios.get('/me', { headers: { Authorization: 'Bearer ' + token } })
    return data
  } catch {
    return null
  }
}

router.beforeEach(async (to, from, next) => {
  const token = localStorage.getItem('token')

  // Sin token, solo deja ir a /login
  if (!token && to.path !== '/login') return next('/login')
  if (to.path === '/login') return next()

  const me = await getMe(token)
  if (!me) return next('/login')

  // Admin: bloquear /report y forzarlo a /admin
  if (me.role === 'admin') {
    if (!to.path.startsWith('/admin')) return next('/admin')
    return next()
  }

  // Leader: bloquear /admin
  if (me.role === 'leader') {
    if (to.path.startsWith('/admin')) return next('/report')
    return next()
  }

  // Por si aparece otro rol
  return next('/login')
})

export default router
