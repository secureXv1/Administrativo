import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { VitePWA } from 'vite-plugin-pwa'

export default defineConfig({
  plugins: [
    vue(),
    VitePWA({
      registerType: 'autoUpdate',
      devOptions: { enabled: true }, // Habilita SW en dev para probar instalación
      includeAssets: ['favicon.ico', 'apple-touch-icon.png', 'robots.txt'],
      manifest: {
        name: 'Novedades PWA',
        short_name: 'Novedades',
        start_url: '/',
        display: 'standalone',
        background_color: '#ffffff',
        theme_color: '#2563eb',
        icons: [
          { src: 'pwa-192x192.png', sizes: '192x192', type: 'image/png' },
          { src: 'pwa-512x512.png', sizes: '512x512', type: 'image/png' },
          // Recomendado para Android: icono "maskable"
          { src: 'pwa-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable any' }
        ],
        shortcuts: [
          { name: 'Dashboard', url: '/admin', icons: [{ src: 'pwa-192x192.png', sizes: '192x192' }] },
          { name: 'Reportar', url: '/report', icons: [{ src: 'pwa-192x192.png', sizes: '192x192' }] }
        ]
      }
    })
  ],
  server: {
    host: true,
    port: 5173,
    proxy: {
      '/auth': 'http://localhost:8080',
      '/reports': 'http://localhost:8080',
      '/me': 'http://localhost:8080',
      '/dashboard': 'http://localhost:8080',
      '/adminapi': 'http://localhost:8080',
      '/catalogs': 'http://localhost:8080',
    }
  }
})
